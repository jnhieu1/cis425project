var itemCheckBox = document.getElementsByClassName("itemCheckBox");



function update(){
	var total = 0;
	for(var i=0; i < itemCheckBox.length; i++){

	if(itemCheckBox[i].checked == true){
		console.log(i + " is checked");
		var idString1 = itemCheckBox[i].id + ".1";
		var idString2 = itemCheckBox[i].id + ".2";

		switch(itemCheckBox[i].id){
			case "1":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "2":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "3":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "4":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "5":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "6":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "7":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "8":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "9":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "10":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "11":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "12":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "13":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "14":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "15":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "16":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "17":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "18":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "19":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "20":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "21":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "22":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "23":
			console.log(idString1);
			console.log(idString2);
				var select = document.getElementById(idString1);

				if(select.value == "Single"){
					console.log("Single");
					document.getElementById(idString2).disabled = false;
					var quantity = document.getElementById(idString2).value;

					total += (quantity * 0.89);

					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
					console.log(total);
				}
				else if(select.value == "halfDozen"){
					console.log("half");
					document.getElementById(idString2).disabled = true;
					total += 5;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				else if(select.value == "dozen"){
					console.log("dozen");
					document.getElementById(idString2).disabled = true;
					total += 8.59;
					//document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);
				}
				break;
			case "24":
				var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "25":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "26":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "27":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "28":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "29":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "30":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "31":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "32":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "33":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "34":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "35":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "36":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "37":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "38":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "39":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "40":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "41":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "42":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "43":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "44":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "45":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "46":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "47":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "48":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "49":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "50":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "51":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "52":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "53":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "54":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "55":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;
			case "56":
			var quantity = document.getElementById(idString1).value;
				console.log(quantity);
				total += (quantity * 2.39);
				break;

		}



	}//end if
	else{
		
	}

}// end for

document.getElementById("subPrice").innerHTML = "$" + total.toFixed(2);

var tax = total * .07;
document.getElementById("tax").innerHTML = "$" + tax.toFixed(2);

var price = tax + total;

document.getElementById("totalPrice").innerHTML = "$" + price.toFixed(2);
}// end function









