
var donuts = document.getElementsByClass("donuts");

